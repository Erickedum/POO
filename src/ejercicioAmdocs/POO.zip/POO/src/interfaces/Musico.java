package interfaces;

public interface Musico extends Persona{

    void tocarMusica();
}
