package interfaces;

public interface Estudiante extends Persona{

    void estudiar();
}
