package interfaces;

public interface Persona {

    void hablar(); //no es obligatorio implementar este metodo en las clases hijas
}
