package interfaces;

public class MusicoEstudiante implements Musico, Estudiante{
    @Override
    public void estudiar() {

    }

    @Override
    public void tocarMusica() {

    }

    @Override
    public void hablar() {

    }
}
